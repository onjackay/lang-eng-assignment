#!/bin/sh
python NER.py -d data/ner_training.csv -t data/ner_test.csv -s
