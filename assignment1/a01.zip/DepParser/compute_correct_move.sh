#!/bin/sh
python dep_parser.py -m en-ud-dev-projective.conllu 
