#!/bin/sh
python CKY.py --grammar grammar2.txt --input_sentence "the suspect faces increased pressure" --print_trees --symbol S

