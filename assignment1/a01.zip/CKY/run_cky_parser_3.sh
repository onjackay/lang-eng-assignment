#!/bin/sh
python CKY.py --grammar grammar3.txt --input_sentence "time flies like an arrow" --print_trees --symbol S

