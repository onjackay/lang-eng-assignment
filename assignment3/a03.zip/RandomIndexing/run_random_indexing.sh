#! /bin/sh
python random_indexing.py